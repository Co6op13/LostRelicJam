using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClientsObjectPooler : ObjectPooler
{   
    #region Singleton
    public static ClientsObjectPooler Instance;

    private void Awake()
    {
        Instance = this;
    }
    #endregion
}
