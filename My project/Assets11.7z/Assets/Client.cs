using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Client : MonoBehaviour
{
    [SerializeField] ManagerPlaces manager;
    private GameObject place;
    

    private void Start()
    {
        if (place ==null)
        {
            place = manager.GetFreePlace();
            if (place.tag != "Place")
            {
                gameObject.SetActive(false);
            }
            
        }
    }


}
