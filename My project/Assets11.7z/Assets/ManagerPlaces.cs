using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerPlaces : MonoBehaviour
{
    [SerializeField] GameObject[] places;
    public bool isFree;     


    public GameObject GetFreePlace()
    {
        for (int i = 0; i < places.Length; i++)
        {
            if (places[i].gameObject.GetComponent<FreePlace>().isFree == true)
            {
                places[i].gameObject.GetComponent<FreePlace>().isFree = false;
                return places[i].gameObject;
            }
        }
        return gameObject;
    }
}
