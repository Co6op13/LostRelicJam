using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxHold : MonoBehaviour
{
    [SerializeField] private float Distance = 1f;
    private Transform position;
    private Rigidbody2D rb;
    private bool hold;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            if (hold != true)
            {
                
            }
        }
        
    }

    
}
