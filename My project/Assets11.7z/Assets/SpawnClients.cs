using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnClients : MonoBehaviour
{
    [SerializeField] Transform min, max;
    [SerializeField] GameObject prefab;
    private GameObject Client;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Spawn());
    }

    protected IEnumerator Spawn()
    {
        while (true)
        {
           
            Client = Instantiate(prefab, new Vector3(Random.Range(min.position.x, max.position.x), transform.position.y, 0f), transform.rotation);
            Client.GetComponent<SpriteRenderer>().color = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
            yield return new WaitForSeconds(2f);


        }
        //while (true)
        //{
        //    Client = ClientsObjectPooler.Instance.GetFromPool(prefab.name, new Vector3(Random.Range(min.position.x, max.position.x), transform.position.y, 0f), transform.rotation);
        //    Client.GetComponent<SpriteRenderer>().color = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f);
        //    yield return new WaitForSeconds(2f);
        //}
    }
}
